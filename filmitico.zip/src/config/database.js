const mongoose = require('mongoose');

const uri = '';

mongoose.connect(uri);

module.exports = mongoose;
